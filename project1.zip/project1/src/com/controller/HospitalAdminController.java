package com.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.pojo.DoctorSchedule;
import com.pojo.adddoc;
import com.pojo.addhospitalmodel;
import com.pojo.patientlistmodel;
import com.pojo.testModel;
import com.service.AuthService;
import com.service.HospitalService;

@Component
@Controller
@RequestMapping("/hospital")
public class HospitalAdminController {

	 @Autowired
	 private AuthService authenticateService1;
	 
	 @Autowired
	 private HospitalService hospitalService;
	
	 @RequestMapping(value = "/adddoc")  
    public ModelAndView display(ModelAndView model)  
    {  
		 adddoc userObj = new adddoc();
		 ModelAndView mv = new ModelAndView();
         mv.setViewName("addDoc");
         mv.addObject("userObj",userObj); 
        return mv;  
    }
	@RequestMapping(value = "/adddoctor")  
    public String display1(@ModelAttribute adddoc userObj)  
    {  
		 System.out.println(userObj.getDoctorid());
		 System.out.println(userObj.getDoctorname());
		 System.out.println(userObj.getEmail());
		 System.out.println(userObj.getHospitalid());
		 System.out.println(userObj.getGender());
		 boolean temp = hospitalService.addDoctortodb(userObj);
		return "redirect:adddoc";
	 
    }
	
	@RequestMapping(value = "/today")  
    public ModelAndView display2(HttpServletRequest request,ModelAndView model)  
    {  
		
		
		List<patientlistmodel> patient_list = new ArrayList<patientlistmodel>();
		patient_list = hospitalService.displayPatientsForIndividualDoctor();
		
		
		List<DoctorSchedule> doclist = new ArrayList<DoctorSchedule>();
		
		// create an object of doctorlist to store doctorname and slots,patients
		DoctorSchedule docObj = null;
		
		String olddoc = "abc";
		String newdoc = null;
		
		boolean firstTime = true;
		for(patientlistmodel obj : patient_list)
		{
			//System.out.println("Id :" + obj.getId());
			//System.out.println("Doctor Id :" + obj.getDoctorid() );
			//System.out.println("Doctor Name :" + obj.getDoctor_name());
			//System.out.println("Patient Name:" + obj.getPatientname());
			//System.out.println("Date :" +obj.getDate() );
			//System.out.println("Slots :" + obj.getSlots());
			
			if(!olddoc.equals(obj.getDoctor_name()) )
			{
				System.out.println("NotEquals");
				
				if(firstTime == false)
				{					//add to list
				    
					doclist.add(docObj);
				   
				}
				firstTime = false; 
				docObj = new DoctorSchedule(); 
				
				// store doctorname and slots with patient in hashmap
				docObj.setDocname(obj.getDoctor_name());
				 
				docObj.docSlot.put(getMilitaryTimings(obj.getSlots()),obj.getPatientname());
			}
			else{
				
				docObj.docSlot.put(getMilitaryTimings(obj.getSlots()),obj.getPatientname());				
				System.out.println("Equals");
			  }
			
			olddoc=obj.getDoctor_name();
			
			
		}
		
		
		doclist.add(docObj);
		System.out.println("Doctor Name      Slot");
		
		for(DoctorSchedule obj1 : doclist )
		{
			System.out.println(obj1.getDocname()+"           "  + obj1.getDocSlot().values());
			
			//System.out.println(obj1.getDocSlot().keySet());
			//System.out.println(obj1.getDocSlot().values());
		}
		
		
		ModelAndView mv = new ModelAndView();
		//HttpSession session = request.getSession();
		//session.setAttribute("doclist", doclist);
        mv.setViewName("TSchedule");
        mv.addObject("doclist",doclist);
        System.out.println("Before going to the view PList.jsp....");
        
      
      return mv;
	 
    }
	
	public String getMilitaryTimings (String str)
	{
		String returnSlot = new String("0");
		
		switch (str)
		{
		case "09-10" : returnSlot = "1"; break;
		case "10-11" : returnSlot = "2"; break;
		case "11-12" : returnSlot = "3"; break;
		case "12-01" : returnSlot = "4"; break;
		case "02-03" : returnSlot = "5"; break;
		case "03-04" : returnSlot = "6"; break;
		case "04-05" : returnSlot = "7"; break;
		case "05-06" : returnSlot = "8"; break;
		}
		
		return returnSlot;
			
			
			
		
		
	}
	
	@RequestMapping(value = "/weekly")  
    public String display3()  
    {  
		return "WSchedule";
	 
    }
	
	  @RequestMapping(value = "/plist")  
	  public ModelAndView displaypatient(ModelAndView model)
	  {
		 List<patientlistmodel> list=new ArrayList<patientlistmodel>(); 
         //List<testModel>PatientList =  authenticateService1.test2();
		 list = hospitalService.listpatients();
	     
		for (patientlistmodel obj : list)
        {
   		  System.out.println("Patient Id :" + obj.getUserID());
          System.out.println("Doctor ID :" + obj.getDoctorid());
          System.out.println("Disease :" + obj.getDisease());
          System.out.println("Status :" + obj.getStatus());
          System.out.println("Prescription Provided :" + obj.getPrescriptionprovided());
     
        }
          ModelAndView mv = new ModelAndView();
          mv.setViewName("PList");
          System.out.println("Before going to the view PList.jsp....");
          mv.addObject("list2",list);
        
        return mv;
        
		 
		
	  }
	  
	 
	
}
