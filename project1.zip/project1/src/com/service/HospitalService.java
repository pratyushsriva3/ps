package com.service;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.orm.hibernate4.HibernateTemplate;

import com.pojo.adddoc;
import com.pojo.addhospitalmodel;
import com.pojo.patientlistmodel;
import com.pojo.testModel;
import com.pojo.loginmodel;
import com.pojo.testModel;
import com.pojo.userhospitalmodel;
import com.service.AuthService;

public class HospitalService {
	
	private HibernateTemplate hibernateTemplate;
    private static Logger log = Logger.getLogger(HospitalService.class);
 
    private HospitalService() { }
 
    public void setHibernateTemplate(HibernateTemplate hibernateTemplate) {
        this.hibernateTemplate = hibernateTemplate;
    }
 
    @SuppressWarnings( { "unchecked", "deprecation" } )
    
    
    public boolean addDoctortodb(adddoc userObj) {
		// TODO Auto-generated method stub
		try{
			hibernateTemplate.save(userObj);
			return true;
		}
		catch(Exception e)
		{
			System.out.println("Exception :" + e);    
			return false;
		}
    	
		
	}
    
    public List<patientlistmodel> displayPatientsForIndividualDoctor() {
		// TODO Auto-generated method stub
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd-MM-yyyy"); 
		LocalDateTime now = LocalDateTime.now();
		String today = dtf.format(now).toString();
		String sqlQuery = "from patientlistmodel where date = ?  order by doctor_id,slots";
        List<patientlistmodel> userObj1 = (List) hibernateTemplate.find(sqlQuery,today);
       
		return userObj1;
	}
    
    public List<patientlistmodel> listpatients() {
		// TODO Auto-generated method stub
		String status = "TIP";
		String sqlQuery = "from patientlistmodel where status = ? ";
        List<patientlistmodel> userObj1 = (List) hibernateTemplate.find(sqlQuery,status);
        return userObj1;
		
		
		//String sqlQuery = "select * from patientlistmodel where status = ? ";            
		//SQLQuery query = session.createSQLQuery(sqlQuery);
		//List<patientlistmodel> pObj = query.list();
		//return pObj;
	 }
    
    public List<testModel> test2() {
		// TODO Auto-generated method stub

		Session em = hibernateTemplate.getSessionFactory().openSession();
		//List<testmodel> bvs = em.createQuery("SELECT new_view FROM testmodel new_view").list();
		SQLQuery query = em.createSQLQuery("select * from new_view");
		//query.addEntity(testmodel.class);
		query.setResultTransformer(Criteria.ALIAS_TO_ENTITY_MAP);
		List results = query.list();
		
		List<testModel> patientList = new ArrayList<testModel>();
		
         for(Object object : results) {
        	 System.out.println(object.toString());
        	 HashMap testObj = (HashMap)object;
        	 testModel testModelObj = new testModel();
        	 testModelObj.setDisease((String)testObj.get("disease"));	        	 
        	 testModelObj.setDoctor_name((String)testObj.get("doctor_name"));
        	 testModelObj.setFirst_name((String)testObj.get("First_name"));
        	 testModelObj.setLast_name((String)testObj.get("Last_name"));
        	 testModelObj.setProgress((String)testObj.get("progress"));
        	 testModelObj.setTableid((int)testObj.get("tableid"));
        	 testModelObj.setUserID((String)testObj.get("UserID"));
        	 
        	 patientList.add(testModelObj);
        	 
	 	              
          }
		
         
		
		 return patientList;
	}
}
