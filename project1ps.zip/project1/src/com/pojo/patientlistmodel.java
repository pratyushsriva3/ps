package com.pojo;

import java.util.*;

public class patientlistmodel {
	
	private int id;
	private String UserID;
	private String doctorid;
	private String disease;
	private String status;
	private String prescriptionprovided;
	private Date datetime;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getUserID() {
		return UserID;
	}
	public void setUserID(String userID) {
		UserID = userID;
	}
	public String getDoctorid() {
		return doctorid;
	}
	public void setDoctorid(String doctorid) {
		this.doctorid = doctorid;
	}
	public String getDisease() {
		return disease;
	}
	public void setDisease(String disease) {
		this.disease = disease;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getPrescriptionprovided() {
		return prescriptionprovided;
	}
	public void setPrescriptionprovided(String prescriptionprovided) {
		this.prescriptionprovided = prescriptionprovided;
	}
	public Date getDatetime() {
		return datetime;
	}
	public void setDatetime(Date datetime) {
		this.datetime = datetime;
	}
	
	
	
}
