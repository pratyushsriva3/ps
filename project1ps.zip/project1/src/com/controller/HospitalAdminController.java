package com.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.pojo.adddoc;
import com.pojo.addhospitalmodel;
import com.pojo.patientlistmodel;
import com.service.AuthService;

@Component
@Controller
@RequestMapping("/hospital")
public class HospitalAdminController {

	 @Autowired
	 private AuthService authenticateService1;
	
	@RequestMapping(value = "/adddoc")  
    public ModelAndView display(ModelAndView model)  
    {  
		 adddoc userObj = new adddoc();
		 ModelAndView mv = new ModelAndView();
         mv.setViewName("addDoc");
         mv.addObject("userObj",userObj); 
        return mv;  
    }
	@RequestMapping(value = "/adddoctor")  
    public String display1(@ModelAttribute adddoc userObj)  
    {  
		 System.out.println(userObj.getDoctorid());
		 System.out.println(userObj.getDoctorname());
		 System.out.println(userObj.getEmail());
		 System.out.println(userObj.getHospitalid());
		 System.out.println(userObj.getGender());
		 boolean temp = authenticateService1.addDoctortodb(userObj);
		return "redirect:adddoc";
	 
    }
	
	@RequestMapping(value = "/today")  
    public String display2()  
    {  
		return "TSchedule";
	 
    }
	
	@RequestMapping(value = "/weekly")  
    public String display3()  
    {  
		return "WSchedule";
	 
    }
	
	  @RequestMapping(value = "/plist")  
	  public ModelAndView displaypatient(ModelAndView model)
	  {
		 List<patientlistmodel> list=new ArrayList<patientlistmodel>(); 
		 list = authenticateService1.listpatients();
	     
		for (patientlistmodel obj : list)
        {
   		  System.out.println("Patient Id :" + obj.getUserID());
          System.out.println("Doctor ID :" + obj.getDoctorid());
          System.out.println("Disease :" + obj.getDisease());
          System.out.println("Status :" + obj.getStatus());
          System.out.println("Prescription Provided :" + obj.getPrescriptionprovided());
     
        }
          ModelAndView mv = new ModelAndView();
          mv.setViewName("PList");
          System.out.println("Before going to the view PList.jsp....");
          mv.addObject("list2",list);
        
        return mv;
		 
		
	  }
	
}
